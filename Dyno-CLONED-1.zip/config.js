module.exports = {
    "registercommands" : false,
     "token": "",
    "imageapi": "bb03f373caa534fcfcbaeae177a65134f44a6e57ba7a7b098be273867b376d8a677ddae3c23c6ded4fec8288573945e8c3483689deb13f229376ad4b5b60231d",
    "ownerID": ["865210696153563156"],
"prefix": "!",
"chat": {
        "url": "http://api.brainshop.ai/get?bid=155777&key=O0Rla6COZJ8XSGPJ&uid=[uid]&msg=[msg]",
        "bid": "155777",
        "key": "O0Rla6COZJ8XSGPJ",
        "uid": "nothing."
    },
    "bid": "874338511464046622",

"api": "AIzaSyAAg3GHxipuyDz7KsCAv434yoFT56TR9LQ",
"youtubeAPI": "AIzaSyAAg3GHxipuyDz7KsCAv434yoFT56TR9LQ",
mainprefix: ".",
"owner": "Skofi",
"mongourl": "mongodb+srv://099:099@cluster0.kjeqb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
"secret": "TKDHwzyl2iieCPgq9mp4O5gttwqEOm1c",
 "dashboardURL": "if you have",
defaultjoinmessage: "{user} Joined Invited By {Inviter} (Inviter Invites: {inv})",
defaultleavemessage: "{user} Left, Invited by {inviter}",
  basiclang: "en", //The basic language of the bot, "fr" for French and "en" for English
    embeds: {
        color: "BLUE", //Embed color (in English)
        footers: "GIVEAWAY :tada: :tada:" //Embed footer
    },

    start: {
        loading: "LOADING XD", //Loading status
        activity: "BRUH" //Status
    },

    events: {
        addcolor: "GREEN", //The color of the event add (in English)
        remcolor: "RED" //The color of the event remove (in English)
    },

    reaction: "🎉", //Reaction to the giveaways if you in the console you see 'unknown emoji' that's what this emoji is not recognized by Discord

    grole: "Giveaway Manager", //If the member doesn't have permission to handle messages he can still use the giveaways commands if he has the role configured right here

    auth: {
        support: "https://discord.gg/btngw4vaTM", //The link of your Discord server
        dperms: "8" //The permissions that the bot asks on we want to add it on a Discord server (8 = moderator)
    },
} 